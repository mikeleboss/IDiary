package com.example.idiary01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class entryView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry_view);
    }
}